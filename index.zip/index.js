// index.js
const sum = require('./alter');

// Rufe die Funktion dreimal auf
sum(3, 5);
sum(10, 20);
sum(7, 13);
